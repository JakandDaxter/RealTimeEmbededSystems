#include <string.h>
#include <stdio.h>

#include "stm32l476xx.h"
#define UPPER_DEFAULT 1050;
#define LOWER_DEFAULT 950;

char str[] = "Give Red LED control input (Y = On, N = off):\r\n";