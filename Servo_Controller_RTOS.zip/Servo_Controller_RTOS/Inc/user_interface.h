#ifndef __USER_INTERFACE_H
#define __USER_INTERFACE_H

#include "main.h"

void test_uart(void);
#endif /*__USER_INTERFACE_H*/